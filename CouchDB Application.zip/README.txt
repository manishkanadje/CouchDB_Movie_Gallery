————————————
Execution
———————————-
1. Start the CouchDB server
2. Run the ‘gui.py’ file
   python gui.py
3. Click Setup Database

———————
You must have CouchDB installed on the system in order
to run this application.